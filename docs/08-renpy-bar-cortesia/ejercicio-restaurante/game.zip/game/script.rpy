# ==========================================
# SPANISH CHALLENGE — Cafetería en Madrid
# ==========================================

default score = 0
default credito_social = 0
default player_name = "Turista"
default avatar = "hombre"

# ------------------------------------------
# Imágenes
# ------------------------------------------

image bg cafeteria_madrid = im.Scale("bg_cafeteria_madrid.png", config.screen_width, config.screen_height)

image turista normal = im.FactorScale("turista.png", 0.95)
image turista feliz = im.FactorScale("turista_feliz.png", 0.60)

image turista_mujer normal = im.FactorScale("turista_mujer.png", 0.55)
image turista_mujer feliz = im.FactorScale("turista_mujer_feliz.png", 0.55)

image camarero normal = im.FactorScale("camarero_normal.png", 0.60)
image camarero enfadado = im.FactorScale("camarero_enfadado.png", 0.60)

image sistema = im.FactorScale("sistema.png", 0.75)

# ------------------------------------------
# Posiciones
# ------------------------------------------

transform pos_turista:
    xalign 0.16
    yalign 1.0

transform pos_camarero:
    xalign 0.84
    yalign 1.0

transform pos_sistema:
    xalign 0.5
    yalign 0.8

# ------------------------------------------
# Personajes
# ------------------------------------------

define turista = Character("[player_name]", color="#c8ffc8")
define camarero = Character("Camarero", color="#ffd28a")
define sys = Character("Sistema", color="#aaddff")

# ------------------------------------------
# Contador de crédito social
# ------------------------------------------

screen contador_credito():
    frame:
        xalign 0.02
        yalign 0.03
        background "#00000088"
        padding (12, 8)
        text "Crédito social: [credito_social]" color "#ffffff" size 24


# ------------------------------------------
# Mostrar avatar elegido
# ------------------------------------------

label mostrar_turista_normal:
    if avatar == "hombre":
        show turista normal at pos_turista
    else:
        show turista_mujer normal at pos_turista
    return

label mostrar_turista_feliz:
    if avatar == "hombre":
        show turista feliz at pos_turista
    else:
        show turista_mujer feliz at pos_turista
    return


# ==========================================
# INICIO
# ==========================================

label start:

    show screen contador_credito

    scene bg cafeteria_madrid
    with fade

    show sistema at pos_sistema

    sys "¡Bienvenido a Spanish Challenge!"
    sys "Vas a practicar español en una cafetería de Madrid."
    sys "El objetivo es conseguir tu desayuno usando fórmulas de cortesía adecuadas."

    menu:
        "Elige tu personaje:"

        "Hombre":
            $ avatar = "hombre"
            $ player_name = "Hombre"

        "Mujer":
            $ avatar = "mujer"
            $ player_name = "Mujer"

    hide sistema

    call escena_1_entrada from _call_escena_1_entrada
    call escena_2_pedido_equivocado from _call_escena_2_pedido_equivocado
    call escena_3_pedir_la_cuenta from _call_escena_3_pedir_la_cuenta

    hide screen contador_credito

    scene bg cafeteria_madrid
    with fade

    show sistema at pos_sistema

    if credito_social >= 5:
        sys "Resultado final: excelente. Has sonado natural, educado y muy adecuado para la situación."
    elif credito_social >= 3:
        sys "Resultado final: bastante bien. Te has comunicado correctamente, aunque puedes suavizar más algunas frases."
    else:
        sys "Resultado final: mejorable. Se entiende lo que quieres decir, pero algunas respuestas han sonado demasiado directas."

    sys "Puntuación final: [score]. Crédito social final: [credito_social]."

    return


# ==========================================
# ESCENA 1 — ENTRAR Y PEDIR MESA
# ==========================================

label escena_1_entrada:

    scene bg cafeteria_madrid
    with fade

    call mostrar_turista_normal from _call_mostrar_turista_normal
    show camarero normal at pos_camarero

    sys "Escena 1: entras en la cafetería. Está bastante llena y el camarero va con prisa."

    camarero "Buenos días. ¿Dígame?"

    sys "Quieres sentarte en una mesa libre junto a la ventana. Elige la opción más adecuada."

    menu:

        "Buenos días. Perdone, ¿podría sentarme en aquella mesa junto a la ventana?":

            $ score += 1
            $ credito_social += 2

            call mostrar_turista_feliz from _call_mostrar_turista_feliz
            show camarero normal at pos_camarero

            turista "Buenos días. Perdone, ¿podría sentarme en aquella mesa junto a la ventana?"
            camarero "Sí, claro. Siéntese donde quiera."

            sys "Muy bien. Has saludado, has usado 'perdone' y has formulado la petición de manera cortés."
            sys "Crédito social +2."

        "Quiero esa mesa.":

            call mostrar_turista_normal from _call_mostrar_turista_normal_1
            show camarero normal at pos_camarero

            turista "Quiero esa mesa."
            camarero "Bueno... sí, puede sentarse ahí."

            sys "La frase es comprensible, pero suena un poco seca."
            sys "Crédito social +0."

        "Oye, dame esa mesa.":

            $ credito_social -= 1

            call mostrar_turista_normal from _call_mostrar_turista_normal_2
            show camarero enfadado at pos_camarero

            turista "Oye, dame esa mesa."
            camarero "Un momento, por favor. No hace falta hablar así."

            sys "Respuesta poco adecuada. Suena brusca para una primera interacción."
            sys "Crédito social -1."

    return


# ==========================================
# ESCENA 2 — PEDIDO EQUIVOCADO
# ==========================================

label escena_2_pedido_equivocado:

    scene bg cafeteria_madrid
    with fade

    call mostrar_turista_normal from _call_mostrar_turista_normal_3
    show camarero normal at pos_camarero

    sys "Escena 2: has pedido un café con leche y una tostada."
    sys "Sin embargo, el camarero te trae un café solo y un cruasán."

    camarero "Aquí tiene: un café solo y un cruasán. Que aproveche."

    sys "Ese no es tu pedido. Tienes que avisarle del error sin parecer maleducado."

    menu:

        "Perdone, creo que ha habido una confusión. Yo había pedido un café con leche y una tostada. ¿Sería posible cambiarlo cuando pueda?":

            $ score += 1
            $ credito_social += 2

            call mostrar_turista_feliz from _call_mostrar_turista_feliz_1
            show camarero normal at pos_camarero

            turista "Perdone, creo que ha habido una confusión. Yo había pedido un café con leche y una tostada. ¿Sería posible cambiarlo cuando pueda?"
            camarero "¡Uy, perdone! Me he confundido de mesa. Ahora mismo se lo cambio."

            sys "Excelente. Has suavizado la queja con 'creo que ha habido una confusión' y '¿sería posible...?'."
            sys "Crédito social +2."

        "Disculpe, este no es mi pedido. Yo pedí un café con leche y una tostada.":

            $ credito_social += 1

            call mostrar_turista_normal from _call_mostrar_turista_normal_4
            show camarero normal at pos_camarero

            turista "Disculpe, este no es mi pedido. Yo pedí un café con leche y una tostada."
            camarero "Ah, vale. Deme un momento y se lo traigo."

            sys "Correcto. Es educado, aunque algo directo."
            sys "Crédito social +1."

        "Esto está mal. Tráigame lo que pedí.":

            $ credito_social -= 1

            call mostrar_turista_normal from _call_mostrar_turista_normal_5
            show camarero enfadado at pos_camarero

            turista "Esto está mal. Tráigame lo que pedí."
            camarero "Bueno, no hace falta ponerse así. Enseguida se lo cambio."

            sys "Poco adecuado. El imperativo 'Tráigame' puede sonar exigente."
            sys "Crédito social -1."

    return


# ==========================================
# ESCENA 3 — PEDIR LA CUENTA
# ==========================================

label escena_3_pedir_la_cuenta:

    scene bg cafeteria_madrid
    with fade

    call mostrar_turista_normal from _call_mostrar_turista_normal_6
    show camarero normal at pos_camarero

    sys "Escena 3: ya has terminado de desayunar y necesitas pedir la cuenta."
    sys "El camarero está atendiendo otra mesa, así que debes llamar su atención con educación."

    menu:

        "Perdone, cuando pueda, ¿me trae la cuenta, por favor?":

            $ score += 1
            $ credito_social += 2

            call mostrar_turista_feliz from _call_mostrar_turista_feliz_2
            show camarero normal at pos_camarero

            turista "Perdone, cuando pueda, ¿me trae la cuenta, por favor?"
            camarero "Sí, claro. Ahora mismo."

            sys "Muy buena respuesta. 'Cuando pueda' y 'por favor' suavizan la petición."
            sys "Crédito social +2."

        "La cuenta, por favor.":

            $ credito_social += 1

            call mostrar_turista_normal from _call_mostrar_turista_normal_7
            show camarero normal at pos_camarero

            turista "La cuenta, por favor."
            camarero "Claro, ahora se la traigo."

            sys "Correcto. Es una forma breve, pero aceptable en una cafetería."
            sys "Crédito social +1."

        "¡Oiga! La cuenta ya.":

            $ credito_social -= 1

            call mostrar_turista_normal from _call_mostrar_turista_normal_8
            show camarero enfadado at pos_camarero

            turista "¡Oiga! La cuenta ya."
            camarero "Ahora voy, pero espere un momento, por favor."

            sys "Respuesta poco adecuada. Suena impaciente y brusca."
            sys "Crédito social -1."

    return